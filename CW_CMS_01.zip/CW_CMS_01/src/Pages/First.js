import image from './image.jpg';
function First(){
    return(
        <>
            <h1> Welcome to Jake's Store</h1>
            <h2> Address : Hornby Street</h2>
            <img src={image} />
        </>
    )

}
export default First;